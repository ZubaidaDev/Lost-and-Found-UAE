package zubaida.begum.adu.ac.ae.lostandfounduae;

import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;

public class AdminDeleteFragment extends Fragment {

    private EditText adminPasswordTxt;
    private Button loginBtn;
    private LinearLayout pendingLayout;
    private DatabaseHelper dbHelper;
    private boolean loggedIn = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // connect fg with xml layout
        View view = inflater.inflate(R.layout.fragment_admin_delete, container, false);

        adminPasswordTxt = view.findViewById(R.id.adminPasswordTxt);
        loginBtn = view.findViewById(R.id.loginBtn);
        pendingLayout = view.findViewById(R.id.pendingLayout);

        dbHelper = new DatabaseHelper(getContext());

        // login btn handler
        ButtonHandler bh = new ButtonHandler();
        loginBtn.setOnClickListener(bh);

        return view;
    }

    public void updateView() {

        //clear old pending items before showing again
        pendingLayout.removeAllViews();

        // heading for pending list
        TextView headingTV = new TextView(getContext());
        headingTV.setText("Pending Items");
        headingTV.setTextSize(22);
        headingTV.setTypeface(Typeface.defaultFromStyle(Typeface.BOLD));
        headingTV.setPadding(0, 10, 0, 20);

        pendingLayout.addView(headingTV);

        // get pending items from db
        ArrayList<Item> items = dbHelper.selectPendingItems();

        if (items.isEmpty()) {

            // show message if no pending items
            TextView emptyTV = new TextView(getContext());
            emptyTV.setText("No pending items");
            emptyTV.setTextSize(18);

            pendingLayout.addView(emptyTV);
            return;
        }

        // radio group used to select item for delete
        RadioGroup group = new RadioGroup(getContext());

        for (Item item : items) {

            // create radio btn for each pending item
            RadioButton rb = new RadioButton(getContext());
            rb.setId(item.getId());

            String text = item.getItemName();
            text += "\n" + item.getDescription();
            text += "\nLocation: " + item.getLocation();
            text += "\nDate: " + item.getDate();
            text += "\nType: " + item.getType().toUpperCase();

            rb.setText(text);
            rb.setTextSize(15);
            rb.setPadding(10, 15, 10, 15);

            group.addView(rb);

            // show selected img from saved image uri
            if (item.getImageLink() != null &&
                    !item.getImageLink().isEmpty()) {

                ImageView imageView = new ImageView(getContext());

                LinearLayout.LayoutParams imageParams =
                        new LinearLayout.LayoutParams(400, 400);

                imageParams.setMargins(40, 0, 0, 20);

                imageView.setLayoutParams(imageParams);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);

                imageView.setImageURI(
                        Uri.parse(item.getImageLink()));

                group.addView(imageView);
            }
        }

        // del selected pending item
        RadioButtonHandler rbh = new RadioButtonHandler();
        group.setOnCheckedChangeListener(rbh);

        pendingLayout.addView(group);
    }

    private class ButtonHandler implements View.OnClickListener {

        @Override
        public void onClick(View view) {

            String password = adminPasswordTxt.getText().toString();//get admin password from input

            if (password.equals("1234")) {

                loggedIn = true;

                Toast.makeText(getContext(),
                        "Admin login successful",
                        Toast.LENGTH_LONG).show();

                updateView(); //to show pending items after login

            } else {

                Toast.makeText(getContext(),
                        "Wrong password",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private class RadioButtonHandler
            implements RadioGroup.OnCheckedChangeListener {

        @Override
        public void onCheckedChanged(
                RadioGroup group,
                int checkedId) {

            if (loggedIn) {// only admin can delete

                dbHelper.deleteById(checkedId);

                Toast.makeText(getContext(),
                        "Item deleted",
                        Toast.LENGTH_LONG).show();

                updateView();//refresh pending list after del
            }
        }
    }
}